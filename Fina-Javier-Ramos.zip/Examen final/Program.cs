﻿using System;

// Clase Program con el menú principal para el gimnasio
public class Program
{
    static void Main(string[] args)
    {
        Gimnasio gimnasio = new Gimnasio();

        // Menú principal
        while (true)
        {
            Console.WriteLine("Seleccione una opción:");
            Console.WriteLine("1. Ingresar datos de cliente");
            Console.WriteLine("2. Mostrar clientes con membresía activa");
            Console.WriteLine("3. Salir del programa");

            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    Console.WriteLine("Ingrese el nombre del cliente:");
                    string nombre = Console.ReadLine();

                    Console.WriteLine("Ingrese la edad del cliente:");
                    int edad = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Ingrese el tipo de membresía (Básica/Premium):");
                    string tipoMembresia = Console.ReadLine();

                    gimnasio.IngresarCliente(nombre, edad, tipoMembresia);
                    Console.WriteLine("Cliente agregado correctamente.");
                    break;
                case "2":
                    gimnasio.MostrarClientesActivos();
                    break;
                case "3":
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }
        }
    }
}
