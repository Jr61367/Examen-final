﻿using System;
using System.Collections.Generic;

// Clase Gimnasio para gestionar los clientes y operaciones del gimnasio
public class Gimnasio
{
    private List<Cliente> clientes;

    // Constructor de la clase Gimnasio
    public Gimnasio()
    {
        clientes = new List<Cliente>();
    }

    // Método para ingresar un nuevo cliente al gimnasio
    public void IngresarCliente(string nombre, int edad, string tipoMembresia)
    {
        Cliente cliente = new Cliente(nombre, edad, tipoMembresia);
        clientes.Add(cliente);
    }

    // Método para mostrar los clientes con membresía activa
    public void MostrarClientesActivos()
    {
        Console.WriteLine("Clientes con membresía activa:");

        foreach (var cliente in clientes)
        {
            if (cliente.ValidarTipoMembresia())
            {
                Console.WriteLine($"Nombre: {cliente.Nombre}, Edad: {cliente.Edad}, Membresía: {cliente.TipoMembresia}");
            }
        }
    }
}
