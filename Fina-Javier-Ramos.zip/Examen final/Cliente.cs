﻿using System;

// Clase Cliente para representar a los clientes del gimnasio
public class Cliente
{
    public string Nombre { get; set; }
    public int Edad { get; set; }
    public string TipoMembresia { get; set; }

    // Constructor de la clase Cliente
    public Cliente(string nombre, int edad, string tipoMembresia)
    {
        Nombre = nombre;
        Edad = edad;
        TipoMembresia = tipoMembresia;
    }

    // Método para validar el tipo de membresía del cliente
    public bool ValidarTipoMembresia()
    {
        return TipoMembresia == "Básica" || TipoMembresia == "Premium";
    }
}
